
package parcial2.gestioncritaturas;

import java.io.IOException;
import model.CasoHawkins;
import model.RegistroHawkins;
import model.clasificacionCaso;


public class Parcial2GestionCritaturas {

    
    public static void main(String[] args) {
        try {
            RegistroHawkins<CasoHawkins> registro = new RegistroHawkins<>();
            registro.agregar(new CasoHawkins(1, "Apertura cerca del laboratorio", "Dr.Brenner", clasificacionCaso.APERTURA_DIMENSIONAL));
            registro.agregar(new CasoHawkins(2, "Actividad psíquica elevada", "Dr.Owens", clasificacionCaso.SUJETO_PSIQUICO));
            registro.agregar(new CasoHawkins(3, "Rastros de entidad en Hawkins", "Jim Hopper", clasificacionCaso.ENTIDAD_HOSTIL));
            registro.agregar(new CasoHawkins(4, "Señales electromagnéticas inusuales", "Nancy Wheeler", clasificacionCaso.FENOMENO_ELECTROMAGNETICO));
            registro.agregar(new CasoHawkins(5, "Desaparición de joven en bosque", "Joyce Byers", clasificacionCaso.DESAPARICION));
            
            System.out.println("Casos registrados:");
            registro.paraCadaElemento(System.out::println);
            
            System.out.println("\nCasos tipo SUJETO_PSIQUICO:");
            registro.filtrar(c -> c.getClasificacion() == clasificacionCaso.SUJETO_PSIQUICO)
            .forEach(System.out::println);
            
            System.out.println("\nCasos que contienen 'portal':");
            registro.filtrar(c -> c.getTitulo().contains("portal"))
            .forEach(System.out::println);
            
            System.out.println("\nCasos ordenados por ID:");
            registro.ordenar((c1, c2) -> Integer.compare(c1.getId(), c2.getId()));
            registro.paraCadaElemento(System.out::println);
            
            System.out.println("\nCasos ordenados por título:");
            registro.ordenar((c1, c2) -> c1.getTitulo().compareToIgnoreCase(c2.getTitulo()));
            registro.paraCadaElemento(System.out::println);
            
            registro.guardarEnArchivo("src/data/casos.dat");
            
            RegistroHawkins<CasoHawkins> cargado = new RegistroHawkins<>();
            cargado.cargarDesdeArchivo("src/data/casos.dat");
            
            System.out.println("\nCasos cargados desde archivo binario:");
            cargado.paraCadaElemento(System.out::println);
            
            registro.guardarEnCSV("src/data/casos.csv");
            
            cargado.cargarDesdeCSV("src/data/casos.csv", linea -> CasoHawkins.fromCSV(linea));
            
            System.out.println("\nCasos cargados desde archivo CSV:");
            cargado.paraCadaElemento(System.out::println);
            
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
    
}
