
package service;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import java.util.function.Function;
import java.util.function.Consumer;



public interface RegistroHawkinsInt <T extends CSVSerializable & Comparable> {
    
    void agregar(T elemento);

    T obtener(int index);

    boolean eliminar(T index);

    List<T> filtrar(Predicate<T> criterio);

    void ordenarNatural();

    void ordenar(Comparator<T> comp);

    void guardarEnArchivo(String path) throws IOException;

    void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException;

    void guardarEnCSV(String path) throws IOException;

    void cargarDesdeCSV(String path, Function<String, T> parser) throws IOException;

    void paraCadaElemento(Consumer<T> accion);
    
}

