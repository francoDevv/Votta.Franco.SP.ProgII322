
package service;

import java.io.Serializable;


public interface CSVSerializable extends Serializable{
    String toCSV();
}
