
package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import service.CSVSerializable;
import service.RegistroHawkinsInt;


public class RegistroHawkins<T extends CSVSerializable & Comparable> implements RegistroHawkinsInt<T>, Serializable {

    private List<T> lista = new ArrayList<>();
    
    @Override
    public void agregar(T elemento) {
        Objects.requireNonNull(elemento, "Elemento nulo");
        lista.add(elemento);
    }

    @Override
    public T obtener(int index) {
        return lista.get(index);
    }

    @Override
    public boolean eliminar(T index) {
        return lista.remove(index);
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> toReturn = new ArrayList<>();
        for(T el : lista) {
            if (criterio.test(el)){
                toReturn.add(el);
            }
        }
        return toReturn;
    }

    @Override
    public void ordenarNatural() {
        Collections.sort(lista);
    }

    @Override
    public void ordenar(Comparator<T> comp) {
        lista.sort(comp);
    }

    @Override
    public void guardarEnArchivo(String path) throws IOException {
        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(path))) {
            oos.writeObject(lista);
            System.out.println("Lista de elementos serializada en:" + path);
        }
    }

    @Override
    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(path))) {
           this.lista = (List<T>) ois.readObject();
            System.out.println("Lista de elementos deserializada desde: " + path);
        } 
    }

    @Override
    public void guardarEnCSV(String path) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            bw.write("Id, Titulo, Investigador, Clasificacion");
            bw.newLine();
            
            for (T el : lista) {
                bw.write(el.toCSV());
                bw.newLine();
            }
            
            System.out.println("Archivo CSV cargado en: " + path);
        } 
    }

    @Override
    public void cargarDesdeCSV(String path, Function<String, T> parser) throws IOException {
        List<T> elementos = new ArrayList<>();
        
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String linea;
            br.readLine();
            
            while((linea = br.readLine()) != null) {
                elementos.add(parser.apply(linea));
            }
        }
        
        this.lista = elementos;
        System.out.println("Archivo CSV cargado desde: " + path);
    }

    @Override
    public void paraCadaElemento(Consumer<T> accion) {
        for (T elem : lista) {
            accion.accept(elem);
        }
    }
    
}
