
package model;

import service.CSVSerializable;


public class CasoHawkins implements Comparable<CasoHawkins>, CSVSerializable{
    
    private int id;
    private String titulo;
    private String investigador;
    private clasificacionCaso clasificacion;

    public CasoHawkins(int id, String titulo, String investigador, clasificacionCaso clasificacion) {
        this.id = id;
        this.titulo = titulo;
        this.investigador = investigador;
        this.clasificacion = clasificacion;
    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getInvestigador() {
        return investigador;
    }

    public clasificacionCaso getClasificacion() {
        return clasificacion;
    }
    
    @Override
    public int compareTo(CasoHawkins o) {
        return Integer.compare(this.id, o.id);
    }

    @Override
    public String toCSV() {
        return id + "," + titulo + "," + investigador + "," + clasificacion;
    }
    
    public static CasoHawkins fromCSV(String linea) {
        String[] p = linea.split(",");
        return new CasoHawkins(
                Integer.parseInt(p[0]),
                p[1],
                p[2],
                clasificacionCaso.valueOf(p[3])
        );   
    } 
    
    @Override
    public String toString() {
        return "CasoHawkins{" + "id=" + id + ", titulo=" + titulo + ", investigador=" + investigador + ", clasificacion=" + clasificacion + '}';
    }
}

